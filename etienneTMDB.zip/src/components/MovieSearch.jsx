import React from "react";
import  { useState, useEffect } from 'react' ;
import { Link } from 'react-router-dom';


const MovieSearch = () => {
    const [query, setQuery] = useState('');
    const [results, setResult] = useState([]);


    useEffect(() => {
        const fetchData = async () => {
            const response = await fetch(`https://api.themoviedb.org/3/search/movie?query=${query}&api_key=72eaf7b03201f089b626e3c6c35a2eed`);
            const data = await response.json();
            setResult(data.results);
        };

        fetchData();
    }, [query]);

    return (
        <div>
            <input type="text" value={query} onChange={e => setQuery(e.target.value)} />
            {results.length > 0 ? (
                <ul className="results">
                    {results.map(result => (
                        <li key={result.id}>
                            <Link to={`/movies/${result.id}`}>{result.title}</Link>
                            
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No results found</p>
            )}
        </div>
    )
}

export default MovieSearch;

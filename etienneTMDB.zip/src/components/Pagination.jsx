import React, { useEffect, useState } from "react";

const PaginationNumber = () => {
    const Pages = () => {
        const [movies, setMovies] = useState([]);
        const [currentPage, setCurrentPage] = useState(1);
        const [totalPages, setTotalPages] = useState(0);

        useEffect(() => {
            fetchMovies();
        }, [currentPage]);

        const fetchMovies = async () => {
            const response = await fetch(`https://api.themoviedb.org/3/movie/popular?api_key=$72eaf7b03201f089b626e3c6c35a2eed&page=${currentPage}`)
            const data = await response.json();
            setMovies(data.results);
            setTotalPages(data.total_pages);
        }
        const renderPagination = () => {
            const pagination = [];
            const maxVisiblePages = 5;
            const totalPageInRange = Math.min(totalPages, maxVisiblePages);

            let startPage;
            let endPage;

            if (totalPages <= maxVisiblePages) {
                startPage = 1;
                endPage = totalPages;
            } else if (currentPage <= Math.ceil(maxVisiblePages / 2)) {
                startPage = 1;
                endPage = maxVisiblePages;
            } else if (currentPage >= totalPages - Math.floor(maxVisiblePages / 2)) {
                startPage = totalPages - maxVisiblePages + 1;
                endPage = totalPages;
            } else {
                startPage = currentPage - Math.floor(maxVisiblePages / 2);
                endPage = currentPage + Math.ceil(maxVisiblePages / 2) - 1;
            }

            pagination.push(
                <button key="previous" onClick={() => handleChange(currentPage - 1)} disabled={currentPage === 1}>Precedent</button>
            )

            for (let i = startPage; i <= endPage; i++) {
                pagination.push(
                    <button key={i} onClick={() => handleChange(i)} className={i === currentPage ? "active" : ""}>{i}</button>
                )
            }

            pagination.push(
                <button key="next" onClick={() => handleChange(currentPage + 1)} disabled={currentPage === totalPages}>Suivant</button>
            )
            if (totalPages > maxVisiblePages) {
                if (currentPage > Math.ceil(maxVisiblePages / 2) + 1) {
                    pagination.unshift(<span key='ellipsis-start'>...</span>)
                }
            }
            return pagination;

        }

        const handleChange = (page) => {
            setCurrentPage(page);
        }


        return (
            <div>
                <h1>Popular Movies</h1>
                <ul>
                    {movies.map((movie) => (
                        <li key={movie.id}>
                            <h2>{movie.title}</h2>
                            <p>{movie.overview}</p>
                        </li>
                    ))}
                </ul>
                <div>
                    {renderPagination()}
                </div>
            </div>
        )
    }


    export default PaginationNumber;
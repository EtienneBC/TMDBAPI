import React, { useState, useEffect } from "react";


const Pages = () => {
    const [movies, setMovies] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(0);

    useEffect(() => {
        fetchMovies();
    }, [currentPage]);

    const fetchMovies = async () => {
        const response = await fetch(`https://api.themoviedb.org/3/movie/popular?api_key=$72eaf7b03201f089b626e3c6c35a2eed&page=${currentPage}`)
        const data = await response.json();
        setMovies(data.results);
        setTotalPages(data.total_pages);
    }

    const handlePreviousPage = () => {
        setCurrentPage((prevPage) => prevPage - 1);
    }

    const handleNextPage = () => {
        setCurrentPage((prevPage) => prevPage + 1);
    }
    
    return (
        <div>
            <h1>Popular Movies</h1>
            <ul>
                {movies.map((movie) => (
                    <li key={movie.id}>
                        <img src={`https://image.tmdb.org/t/p/w185_and_h278_bestv2/${movie.poster_path}`} alt={movie.title + " poster"} />
                        <h2>{movie.title}</h2>
                        <p>{movie.overview}</p>
                    </li>
                ))}
            </ul>
            <div>
                <button onClick={handlePreviousPage} disabled={currentPage === 1}>Precedent</button>
                <button onClick={handleNextPage} disabled={currentPage === totalPages}>Suivant</button>
            </div>
            
        </div>
    );
}

export default Pages;
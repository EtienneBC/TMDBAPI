import React from "react";
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import WatchlistButton from './Watchlist.jsx';

function FreeWatchCarousel() {
  const [PopularData, setPopularData] = useState([]);

  useEffect(() => {
    const fetchTrendingData = async () => {
      const response = await fetch(
        'https://api.themoviedb.org/3/movie/popular?api_key=72eaf7b03201f089b626e3c6c35a2eed'
      );
      const data = await response.json();
      setPopularData(data.results);
    };

    fetchTrendingData();
  }, []);

  return (
    <div>
      <h2>Popular Movies</h2>
      <div className="carousel">
        {PopularData.map((item) => (
          <div key={item.id}>
            <img
              src={`https://image.tmdb.org/t/p/w500${item.poster_path}`}
              alt={item.title || item.name}
            />
            <p>
              <Link to={`/movies/${item.id}`}>{item.title}</Link>
              <Link to={`/series/${item.id}`}>{item.name}</Link>
            </p>
            <WatchlistButton itemId={item.id} toWatch={item.title} mediaType={item.media_type} />
          </div>
        ))}
      </div>
    </div>
  );
}

export default FreeWatchCarousel;

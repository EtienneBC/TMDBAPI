import React, { useState, useEffect } from "react";
import { Collapse, Text, Grid, Checkbox, Radio, Button } from "@nextui-org/react";

export default function SearchBar() {
    const [categories, setCategories] = useState([]);
    const [selectedSortOption, setSelectedSortOption] = useState("popularity.desc");
    const [selectedGenreOptions, setSelectedGenreOptions] = useState([]);
    const [selectedDecadeOption, setSelectedDecadeOption] = useState("");
    const [searchResults, setSearchResults] = useState([]); // Add searchResults state

    useEffect(() => {
        const fetchMovieCategories = async () => {
            try {
                const response = await fetch(
                    "https://api.themoviedb.org/3/genre/movie/list?api_key=72eaf7b03201f089b626e3c6c35a2eed"
                );
                const data = await response.json();
                setCategories(data.genres);
            } catch (err) {
                console.log("Error fetching categories", err);
            }
        };

        fetchMovieCategories();
    }, []);

    const handleSearch = async () => {
        // You can use the selected options to fetch the movies
        console.log("Selected Sort Option:", selectedSortOption);
        console.log("Selected Genre Options:", selectedGenreOptions);
        console.log("Selected Decade Option:", selectedDecadeOption);

        try {
            const response = await fetch(
                `https://api.themoviedb.org/3/discover/movie?api_key=72eaf7b03201f089b626e3c6c35a2eed&sort_by=${selectedSortOption}&with_genres=${selectedGenreOptions.join(
                    ","
                )}&year=${selectedDecadeOption}`
            );
            const data = await response.json();
            setSearchResults(data.results.slice(0, 21)); // Slice the first 21 results
        } catch (error) {
            console.error("Error fetching movies", error);
        }
    };

    return (
        <div>
            <Grid>
                <Collapse.Group shadow>
                    <Collapse title="Sort">
                        <Radio.Group
                            label="Options"
                            defaultValue="popularity.desc" 
                            value={selectedSortOption}
                            onChange={(value) => setSelectedSortOption(value)}
                        >
                            <Radio value="popularity.desc">Popularity descending</Radio>
                            <Radio value="popularity.asc">Popularity ascending</Radio>
                            <Radio value="vote_average.desc">Score descending</Radio>
                            <Radio value="vote_average.asc">Score ascending</Radio>
                        </Radio.Group>
                    </Collapse>
                </Collapse.Group>
                <Collapse.Group shadow>
                    <Collapse title="Genre">
                        {categories.map((category) => (
                            <Checkbox
                                key={category.id}
                                value={category.id}
                                checked={selectedGenreOptions.includes(category.id)}
                                onChange={(checked) =>
                                    setSelectedGenreOptions((prev) =>
                                        checked
                                            ? [...prev, category.id]
                                            : prev.filter((id) => id !== category.id)
                                    )
                                }
                            >
                                {category.name}
                            </Checkbox>
                        ))}
                    </Collapse>
                </Collapse.Group>
                <Collapse.Group shadow>
                    <Collapse title="Decade">
                        <Radio.Group
                            label="Options"
                            value={selectedDecadeOption}
                            onChange={(value) => setSelectedDecadeOption(value)}
                        >
                            <Radio value="1940-1950">1940s</Radio>
                            <Radio value="1950-1960">1950s</Radio>
                            <Radio value="1960-1970">1960s</Radio>
                            <Radio value="1970-1980">1970s</Radio>
                            <Radio value="1980-1990">1980s</Radio>
                            <Radio value="1990-2000">1990s</Radio>
                            <Radio value="2000-2010">2000s</Radio>
                            <Radio value="2010-2020">2010s</Radio>
                            <Radio value="2020-2030">2020s</Radio>
                        </Radio.Group>
                    </Collapse>
                </Collapse.Group>
                <Button auto type="success" onClick={handleSearch}>
                    Search
                </Button>
            </Grid>
            {/* Results */}
            <Text h3>Results</Text>
            <Grid.Container gap={2} justify="center">
                {searchResults.map((movie) => (
                    <Grid xs={12} md={6} lg={4} key={movie.id}>
                        <img
                            src={`https://image.tmdb.org/t/p/w200${movie.poster_path}`}
                            alt="Movie poster"
                        />
                        <Text h4>{movie.title}</Text>
                        <Text>{movie.release_date}</Text>
                        <Text>{movie.vote_average}</Text>
                    </Grid>
                ))}
            </Grid.Container>
        </div>
    );
}

import React, { useState, useEffect } from "react";
import { useParams, Link } from 'react-router-dom';
import WatchlistButton from './WatchlistButton.jsx';



function MoviesByCategory() {
    const [movies, setMovies] = useState([]);
    const { categoryId, categoryName, mediaType } = useParams();

    console.log(categoryId, categoryName, mediaType),
        useEffect(() => {
            const fetchMoviesByCategory = async () => {
                try {
                    const response = await fetch(
                        `https://api.themoviedb.org/3/discover/${mediaType}?api_key=72eaf7b03201f089b626e3c6c35a2eed&with_genres=${categoryId}`
                    );
                    const data = await response.json();
                    setMovies(data.results);
                } catch (err) {
                    console.log("Error fetching movies by category", err);
                }
            };
            fetchMoviesByCategory();
        }, [categoryId, categoryName]);

    return (
        <div className="carouselContainer">
            <h2>Category {categoryName}</h2>
            <div className="carousel">
                {movies.map((movie) => (
                    <div key={movie.id}>
                        <img
                            src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
                            alt={movie.title || movie.name}
                        />
                        <p>
                            <Link to={`/movies/${movie.id}`}>{movie.title}</Link>
                            <Link to={`/series/${movie.id}`}>{movie.name}</Link>
                        </p>
                        <WatchlistButton itemId={movie.id} toWatch={movie.title} mediaType={movie.media_type} />
                    </div>
                ))}
            </div>
        </div>
    );
}

export default MoviesByCategory;

import React from "react";
import { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, useParams } from 'react-router-dom';

const SerieDetails = () => {
    const { seriesId } = useParams();
    const [serie, setSerie] = useState(null);
    const [actors, setActors] = useState([]);

    useEffect(() => {
        fetch(`https://api.themoviedb.org/3/tv/${seriesId}?api_key=72eaf7b03201f089b626e3c6c35a2eed`)
        .then(response => response.json())
        .then(data => setSerie(data))
        .catch(error => console.log(error));
        
        fetch(`https://api.themoviedb.org/3/tv/${seriesId}/aggregate_credits?api_key=72eaf7b03201f089b626e3c6c35a2eed`)
        .then(response => response.json())
        .then(data => setActors(data.cast))
        .catch(error => console.log(error));
        
    }, [seriesId]);


    if (!serie) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            <h2>{serie.name}</h2>
            <img src={`https://image.tmdb.org/t/p/w500${serie.poster_path}`} alt={serie.name} />
            <p>{serie.overview}</p>
            <p>Number of Seasons: {serie.number_of_seasons}</p>
            <p>Number of Episodes: {serie.number_of_episodes}</p>
            <p>First Air Date: {serie.first_air_date}</p>
            <p>Last Air Date: {serie.last_air_date}</p>
            <h3>Actors</h3>
            <ul>
                {actors.map(actor => (
                    <li key={actor.id}>
                        <Link to={`/actors/${actor.id}`}>{actor.name}</Link>
                    </li>
                ))}
            </ul>
        </div>

    );
};

export default SerieDetails;

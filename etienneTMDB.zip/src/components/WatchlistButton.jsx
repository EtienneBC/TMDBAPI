import React from "react";
import { Button } from "@nextui-org/react";
import StarIcon from "./Icons.jsx";

function handleWatchlist(event, itemId, isSeries) {
  if (localStorage.getItem('isLogged') === 'true') {
    const watchlist = localStorage.getItem('Watchlist');
    const updatedWatchlist = watchlist ? `${watchlist},${itemId}:${isSeries ? 'series' : 'movie'}` : `${itemId}:${isSeries ? 'series' : 'movie'}`;
    localStorage.setItem('Watchlist', updatedWatchlist);
  }
}

function WatchlistButton({ itemId, toWatch, mediaType }) {
  const isLogged = localStorage.getItem('isLogged');
  if (!isLogged) {
    return null;
  }

  const isSeries = mediaType === 'tv';

  return (
    <div>
      <Button auto onClick={(event) => handleWatchlist(event, itemId, isSeries)}>
        <StarIcon />
      </Button>
    </div>
  );
}

export default WatchlistButton;

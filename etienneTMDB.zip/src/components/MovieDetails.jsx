import React from "react";
import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import WatchlistButton from "./WatchlistButton.jsx";
import { Grid, Image, Button, Spinner, Spacer, Card } from "@nextui-org/react"
import Nav from "./Navbar.jsx";

const ActorDetails = () => {
  const { movieId } = useParams();
  const [movie, setMovie] = useState(null);
  const [actors, setActors] = useState([]);

  function MovieRuntime({ runtime }) {
    const hours = Math.floor(runtime / 60);
    const minutes = runtime % 60;

    return (
      <p>
        Runtime: {hours}h{minutes < 10 ? `0${minutes}` : minutes}min
      </p>
    );
  }

  useEffect(() => {
    fetch(`https://api.themoviedb.org/3/movie/${movieId}?api_key=72eaf7b03201f089b626e3c6c35a2eed`)
      .then(response => response.json())
      .then(data => setMovie(data))
      .catch(error => console.log(error));

    fetch(`https://api.themoviedb.org/3/movie/${movieId}/credits?api_key=72eaf7b03201f089b626e3c6c35a2eed`)
      .then(response => response.json())
      .then(data => setActors(data.cast))
      .catch(error => console.log(error));
  }, [movieId]);

  if (!movie) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <Nav />
      <div className="container">
        <Spacer y={3} />
        <Grid.Container justify="center">
          <Grid xs={12} sm={6}>
            <img src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`} alt={movie.title} />
          </Grid>
          <Grid xs={12} sm={6} direction="column">
            <h2>{movie.title}</h2>
            <p>{movie.tagline}</p>
            <p>Release date: {movie.release_date}</p>
            <Spacer y={1} />
            <p>Rating: {movie.vote_average}</p>
            <MovieRuntime runtime={movie.runtime}></MovieRuntime>
            <p>Genres: {movie.genres.map(genre => genre.name).join(', ')}</p>
            <Spacer y={1} />
            <p>{movie.overview}</p>
            <Spacer y={1} />
            <WatchlistButton itemId={movie.id} toWatch={movie.title} mediaType={movie.media_type} />
            <Spacer y={1} />
            

          </Grid>
        </Grid.Container>
        <div>
          <h3>Actors</h3>
          {actors.map(actor => (
            <Card key={actor.id}>
              <Link to={`/actors/${actor.id}`}>{actor.name}</Link>
            </Card>
          ))}
        </div>
      </div>
    </>
  );
};

export default ActorDetails;
import React, { useState } from "react";

function FormValidation(){
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
    });
    const [formeErrors, setFormErrors] = useState({
        firstName: '',
        lastName: '',
        email: '',
    });

    //handleChange
const handleChange = (event) => {
    const {name, value} = event.target;
    setFormData((prevData) => ({
        ...prevData,
        [name]: value
    }));
    setFormErrors((prevErrors) => ({
            ...prevErrors,
            [name] : ''
    }))
    
}

const handleSumblit = (event) => {
    event.preventDefault();
    if(validateForm()) {
        console.log(formData);
    }

}

const validateForm =() => {
    let isValid = true;
    const {firstName, lastName, email} = formData;
    const newErrors = {
        firstName: '',
        lastName:'',
        email:'',
    }
    if(!firstName) {
        newErrors.firstName = "Mets dequoi dans le champs firstName plz"
        isValid = false;
    }
    if(!lastName) {
        newErrors.lastName = "Mets dequoi dans le champs lastName plz"
        isValid = false;
    }
    if(!email) {
        newErrors.email = "Mets dequoi dans le champs email plz"
        isValid = false;
    } else if (!isValidEmail(email)) {
        newErrors.email = "Ton email est pas bon :("
        isValid = false;
    }
    setFormErrors(newErrors);


}
// isValidEmail
    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }


    return (
        <div>
            <form onSubmit={handleSumblit}>
                <label>
                    FirstName
                <input type="text" 
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    />
                    <div>{formeErrors.firstName}</div>
                </label>
                <br />
                <label>
                    lastName
                <input 
                    type="text" 
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    />
                    <div>{formeErrors.lastName}</div>
                </label>
                <br />
                <label>
                    email
                <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    
                    />
                    <div>{formeErrors.email}</div>
                </label>
                <br />
                <button type="submit">Soumettre</button>
            </form>
        </div>
    )
}


export default FormValidation
import React, { useState } from 'react';
import { Link as NavLink } from 'react-router-dom';

import Login from "./Login.jsx";

function Nav() {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const navStyle = "bg-gray-800 text-white shadow-lg";
    const brandStyle = "text-xs font-bold ml-4";
    const linkStyle = "hover:bg-gray-700 px-4 py-2 rounded";

    return (
        <nav className={navStyle}>
            <div className="hidden sm:flex space-x-6">
                <NavLink to="/movies" className={linkStyle}>Movies</NavLink>
                <NavLink to="/series" className={linkStyle}>Series</NavLink>
                <NavLink to="/actors" className={linkStyle}>Actors</NavLink>
                <NavLink to="/categories" className={linkStyle}>Categories</NavLink>
                <NavLink to="/about" className={linkStyle}>About</NavLink>
                <Login />
            </div>
        </nav>
    );
}

export default Nav;

import React, { useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import { Splide, SplideSlide } from '@splidejs/react-splide';

function ActorList() {
    const [cast, setCast] = useState([]);

    useEffect(() => {
        const fetchActors = async () => {
            try {
                const response = await fetch(
                    'https://api.themoviedb.org/3/trending/person/week?api_key=72eaf7b03201f089b626e3c6c35a2eed'
                );
                const data = await response.json()
                setCast(data.results)
            } catch (err) {
                console.log("Error fetching data", err);
            }
        }
        fetchActors()
    }, []);

    return (
        <div>
            <h2>Personnes populaire</h2>
            <Splide className="carousel"
        tag="div"
        options={{
          rewind: true,
          gap: '1rem',
          perPage: 5,
          width: '100%',
        }}>
                {cast.map((data) => (
                    <SplideSlide key={data.id}>
                        <Link to={`/actors/${data.id}`}>
                        <img src={`https://image.tmdb.org/t/p/w200${data.profile_path}`} alt={data.name} />
                        <h3>{data.name}</h3></Link>
                    </SplideSlide>
                ))}
            </Splide>
        </div>
    )
}
export default ActorList;
import React from "react";
import MovieSearch from "../components/MovieSearch.jsx";
import MovieList from "../components/fetchMovie.jsx";
import {MovieCategories, SeriesCategories} from "../components/Categories.jsx";
import SearchBar from "../components/searchBar.jsx";


const MoviePage = () => {
return (
    <div>
      <h1>Movies</h1>
      <MovieSearch />
      <MovieCategories />
      <MovieList/>
      <SearchBar />
    </div>
    );
};

export default MoviePage;

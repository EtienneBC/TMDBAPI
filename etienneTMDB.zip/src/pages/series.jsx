import React from "react";
import SeriesList from "../components/fetchSeries.jsx";


const SeriePage = () => {
return (
    <div>
      <h1>Movies</h1>
      <SeriesList/>
    </div>
    );
};

export default SeriePage;

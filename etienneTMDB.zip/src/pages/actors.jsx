import React from "react";
import ActorList from "../components/fetchActors.jsx";

function ActorPage() {
    return (
        <div>
        <ActorList />
        </div>
    );
    }
export default ActorPage;
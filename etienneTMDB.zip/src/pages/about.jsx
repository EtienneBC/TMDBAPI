import React from "react";
import { Link } from "react-router-dom";

function About() {
    return (
        <div>
            <p>About us</p>
            <p>“Welcome to Stargaze, your go-to movie database website! We are
                a team of passionate movie lovers who have created this website
                using React and Bootstrap. We use the TMDB API to provide you with
                the latest information on movies. Our goal is to make it easy for you
                to find your favorite movies and discover new ones. We hope you
                enjoy using our website as much as we enjoyed creating it!”</p>
            <Link to="/">Retour a la page d'acceuil</Link>

        </div>
    )
}

export default About;